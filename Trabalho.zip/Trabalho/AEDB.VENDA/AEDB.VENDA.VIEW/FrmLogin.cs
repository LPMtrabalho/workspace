﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AEDB.VENDA.VIEW.Controllers;
using AEDB.VENDA.MODEL;

namespace AEDB.VENDA.VIEW
{
    public partial class FrmLogin : Form
    {
        private CLogin _Control = new CLogin();
        private bool _Autenticado = false;

        public bool Autenticado
        {
            get { return _Autenticado; }
        }

        public FrmLogin()
        {
            InitializeComponent();
        }

        private bool ValidaControles()
        {
            return true;
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {

        }

        private void BtnEntrar_Click(object sender, EventArgs e)
        {
            if (ValidaControles())
            {
                var Usuario = _Control.Autenticar(TxtUsuEmail.Text, TxtUsuSenha.Text);
                if (Usuario == null)
                {
                    MessageBox.Show("Usuário ou senha inválidos.", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    if (Usuario.UsuBloqueado)
                    {
                        MessageBox.Show("Acesso Bloqueado.Motivo: " + Usuario.UsuMotivoBloqueio, ProductName, MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                    else
                    {
                        if(Usuario.UsuExpiraProximoLogon)
                        {

                        }
                        else
                        {
                            _Autenticado = true;
                            this.Close();
                        }
                    }
                }
            } 
        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
