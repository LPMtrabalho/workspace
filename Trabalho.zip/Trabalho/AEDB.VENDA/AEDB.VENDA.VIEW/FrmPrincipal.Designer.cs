﻿namespace AEDB.VENDA.VIEW
{
    partial class FrmPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.MnuCadastros = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuCadFuncionario = new System.Windows.Forms.ToolStripMenuItem();
            this.MnuCadCliente = new System.Windows.Forms.ToolStripMenuItem();
            this.registroDeVendasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripSeparator();
            this.sairToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuCadastros,
            this.registroDeVendasToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // MnuCadastros
            // 
            this.MnuCadastros.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MnuCadFuncionario,
            this.MnuCadCliente,
            this.toolStripMenuItem1,
            this.sairToolStripMenuItem1});
            this.MnuCadastros.Name = "MnuCadastros";
            this.MnuCadastros.Size = new System.Drawing.Size(71, 20);
            this.MnuCadastros.Text = "&Cadastros";
            // 
            // MnuCadFuncionario
            // 
            this.MnuCadFuncionario.Name = "MnuCadFuncionario";
            this.MnuCadFuncionario.Size = new System.Drawing.Size(180, 22);
            this.MnuCadFuncionario.Text = "&Funcionários";
            this.MnuCadFuncionario.Click += new System.EventHandler(this.MnuCadFuncionario_Click);
            // 
            // MnuCadCliente
            // 
            this.MnuCadCliente.Name = "MnuCadCliente";
            this.MnuCadCliente.Size = new System.Drawing.Size(180, 22);
            this.MnuCadCliente.Text = "C&liente";
            this.MnuCadCliente.Click += new System.EventHandler(this.MnuCadCliente_Click);
            // 
            // registroDeVendasToolStripMenuItem
            // 
            this.registroDeVendasToolStripMenuItem.Name = "registroDeVendasToolStripMenuItem";
            this.registroDeVendasToolStripMenuItem.Size = new System.Drawing.Size(118, 20);
            this.registroDeVendasToolStripMenuItem.Text = "&Registro de Vendas";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(177, 6);
            // 
            // sairToolStripMenuItem1
            // 
            this.sairToolStripMenuItem1.Name = "sairToolStripMenuItem1";
            this.sairToolStripMenuItem1.Size = new System.Drawing.Size(180, 22);
            this.sairToolStripMenuItem1.Text = "Sai&r";
            this.sairToolStripMenuItem1.Click += new System.EventHandler(this.sairToolStripMenuItem1_Click);
            // 
            // FrmPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrmPrincipal";
            this.Text = "Formulário Principal";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.FrmPrincipal_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem MnuCadastros;
        public System.Windows.Forms.ToolStripMenuItem MnuCadFuncionario;
        public System.Windows.Forms.ToolStripMenuItem MnuCadCliente;
        private System.Windows.Forms.ToolStripMenuItem registroDeVendasToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem sairToolStripMenuItem1;
    }
}