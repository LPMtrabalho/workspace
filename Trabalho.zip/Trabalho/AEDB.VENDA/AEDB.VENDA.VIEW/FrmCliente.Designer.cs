﻿namespace AEDB.VENDA.VIEW
{
    partial class FrmCliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.BtnConfirmaAlteracao = new System.Windows.Forms.Button();
            this.BtnFechar = new System.Windows.Forms.Button();
            this.BtnIncluir = new System.Windows.Forms.Button();
            this.LblCPF = new System.Windows.Forms.Label();
            this.LblFunNumero = new System.Windows.Forms.Label();
            this.TxtCliCidade = new System.Windows.Forms.TextBox();
            this.TxtCliBairro = new System.Windows.Forms.TextBox();
            this.TxtCliRua = new System.Windows.Forms.TextBox();
            this.TxtCliTel = new System.Windows.Forms.TextBox();
            this.TxtCliCPF = new System.Windows.Forms.TextBox();
            this.LblCidade = new System.Windows.Forms.Label();
            this.LblBairro = new System.Windows.Forms.Label();
            this.LblRua = new System.Windows.Forms.Label();
            this.TxtCliCod = new System.Windows.Forms.TextBox();
            this.TxtCliNome = new System.Windows.Forms.TextBox();
            this.LblCodigo = new System.Windows.Forms.Label();
            this.LblNome = new System.Windows.Forms.Label();
            this.GrdClientes = new System.Windows.Forms.DataGridView();
            this.CliCodigo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CliNome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CliCNPJ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CliCPF = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CliNumero = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CliRua = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CliBairro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CliCidade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BtnExcluir = new System.Windows.Forms.DataGridViewButtonColumn();
            this.BtnAlterar = new System.Windows.Forms.DataGridViewButtonColumn();
            this.LblCliCNPJ = new System.Windows.Forms.Label();
            this.TxtCliCNPJ = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.GrdClientes)).BeginInit();
            this.SuspendLayout();
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.Location = new System.Drawing.Point(93, 153);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(75, 21);
            this.BtnCancelar.TabIndex = 28;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.UseVisualStyleBackColor = true;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // BtnConfirmaAlteracao
            // 
            this.BtnConfirmaAlteracao.Location = new System.Drawing.Point(12, 153);
            this.BtnConfirmaAlteracao.Name = "BtnConfirmaAlteracao";
            this.BtnConfirmaAlteracao.Size = new System.Drawing.Size(75, 21);
            this.BtnConfirmaAlteracao.TabIndex = 27;
            this.BtnConfirmaAlteracao.Text = "Alterar";
            this.BtnConfirmaAlteracao.UseVisualStyleBackColor = true;
            this.BtnConfirmaAlteracao.Click += new System.EventHandler(this.BtnConfirmaAlteracao_Click);
            // 
            // BtnFechar
            // 
            this.BtnFechar.Location = new System.Drawing.Point(12, 12);
            this.BtnFechar.Name = "BtnFechar";
            this.BtnFechar.Size = new System.Drawing.Size(75, 23);
            this.BtnFechar.TabIndex = 26;
            this.BtnFechar.Text = "Fechar";
            this.BtnFechar.UseVisualStyleBackColor = true;
            this.BtnFechar.Click += new System.EventHandler(this.BtnFechar_Click);
            // 
            // BtnIncluir
            // 
            this.BtnIncluir.Location = new System.Drawing.Point(395, 90);
            this.BtnIncluir.Name = "BtnIncluir";
            this.BtnIncluir.Size = new System.Drawing.Size(75, 21);
            this.BtnIncluir.TabIndex = 25;
            this.BtnIncluir.Text = "Incluir";
            this.BtnIncluir.UseVisualStyleBackColor = true;
            this.BtnIncluir.Click += new System.EventHandler(this.BtnIncluir_Click);
            // 
            // LblCPF
            // 
            this.LblCPF.AutoSize = true;
            this.LblCPF.Location = new System.Drawing.Point(442, 67);
            this.LblCPF.Name = "LblCPF";
            this.LblCPF.Size = new System.Drawing.Size(27, 13);
            this.LblCPF.TabIndex = 11;
            this.LblCPF.Text = "CPF";
            // 
            // LblFunNumero
            // 
            this.LblFunNumero.AutoSize = true;
            this.LblFunNumero.Location = new System.Drawing.Point(557, 67);
            this.LblFunNumero.Name = "LblFunNumero";
            this.LblFunNumero.Size = new System.Drawing.Size(49, 13);
            this.LblFunNumero.TabIndex = 12;
            this.LblFunNumero.Text = "Telefone";
            // 
            // TxtCliCidade
            // 
            this.TxtCliCidade.Location = new System.Drawing.Point(307, 91);
            this.TxtCliCidade.MaxLength = 50;
            this.TxtCliCidade.Name = "TxtCliCidade";
            this.TxtCliCidade.Size = new System.Drawing.Size(82, 20);
            this.TxtCliCidade.TabIndex = 23;
            // 
            // TxtCliBairro
            // 
            this.TxtCliBairro.Location = new System.Drawing.Point(173, 90);
            this.TxtCliBairro.MaxLength = 20;
            this.TxtCliBairro.Name = "TxtCliBairro";
            this.TxtCliBairro.Size = new System.Drawing.Size(82, 20);
            this.TxtCliBairro.TabIndex = 22;
            // 
            // TxtCliRua
            // 
            this.TxtCliRua.Location = new System.Drawing.Point(45, 90);
            this.TxtCliRua.MaxLength = 20;
            this.TxtCliRua.Name = "TxtCliRua";
            this.TxtCliRua.Size = new System.Drawing.Size(82, 20);
            this.TxtCliRua.TabIndex = 21;
            // 
            // TxtCliTel
            // 
            this.TxtCliTel.Location = new System.Drawing.Point(612, 64);
            this.TxtCliTel.MaxLength = 20;
            this.TxtCliTel.Name = "TxtCliTel";
            this.TxtCliTel.Size = new System.Drawing.Size(76, 20);
            this.TxtCliTel.TabIndex = 24;
            // 
            // TxtCliCPF
            // 
            this.TxtCliCPF.Location = new System.Drawing.Point(475, 64);
            this.TxtCliCPF.MaxLength = 11;
            this.TxtCliCPF.Name = "TxtCliCPF";
            this.TxtCliCPF.Size = new System.Drawing.Size(76, 20);
            this.TxtCliCPF.TabIndex = 19;
            // 
            // LblCidade
            // 
            this.LblCidade.AutoSize = true;
            this.LblCidade.Location = new System.Drawing.Point(261, 94);
            this.LblCidade.Name = "LblCidade";
            this.LblCidade.Size = new System.Drawing.Size(40, 13);
            this.LblCidade.TabIndex = 15;
            this.LblCidade.Text = "Cidade";
            // 
            // LblBairro
            // 
            this.LblBairro.AutoSize = true;
            this.LblBairro.Location = new System.Drawing.Point(133, 93);
            this.LblBairro.Name = "LblBairro";
            this.LblBairro.Size = new System.Drawing.Size(34, 13);
            this.LblBairro.TabIndex = 14;
            this.LblBairro.Text = "Bairro";
            // 
            // LblRua
            // 
            this.LblRua.AutoSize = true;
            this.LblRua.Location = new System.Drawing.Point(12, 93);
            this.LblRua.Name = "LblRua";
            this.LblRua.Size = new System.Drawing.Size(27, 13);
            this.LblRua.TabIndex = 13;
            this.LblRua.Text = "Rua";
            // 
            // TxtCliCod
            // 
            this.TxtCliCod.Location = new System.Drawing.Point(50, 38);
            this.TxtCliCod.MaxLength = 20;
            this.TxtCliCod.Name = "TxtCliCod";
            this.TxtCliCod.Size = new System.Drawing.Size(58, 20);
            this.TxtCliCod.TabIndex = 18;
            // 
            // TxtCliNome
            // 
            this.TxtCliNome.Location = new System.Drawing.Point(50, 64);
            this.TxtCliNome.MaxLength = 50;
            this.TxtCliNome.Name = "TxtCliNome";
            this.TxtCliNome.Size = new System.Drawing.Size(264, 20);
            this.TxtCliNome.TabIndex = 17;
            // 
            // LblCodigo
            // 
            this.LblCodigo.AutoSize = true;
            this.LblCodigo.Location = new System.Drawing.Point(12, 41);
            this.LblCodigo.Name = "LblCodigo";
            this.LblCodigo.Size = new System.Drawing.Size(40, 13);
            this.LblCodigo.TabIndex = 9;
            this.LblCodigo.Text = "Código";
            // 
            // LblNome
            // 
            this.LblNome.AutoSize = true;
            this.LblNome.Location = new System.Drawing.Point(12, 67);
            this.LblNome.Name = "LblNome";
            this.LblNome.Size = new System.Drawing.Size(35, 13);
            this.LblNome.TabIndex = 16;
            this.LblNome.Text = "Nome";
            // 
            // GrdClientes
            // 
            this.GrdClientes.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrdClientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GrdClientes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.CliCodigo,
            this.CliNome,
            this.CliCNPJ,
            this.CliCPF,
            this.CliNumero,
            this.CliRua,
            this.CliBairro,
            this.CliCidade,
            this.BtnExcluir,
            this.BtnAlterar});
            this.GrdClientes.Location = new System.Drawing.Point(12, 180);
            this.GrdClientes.Name = "GrdClientes";
            this.GrdClientes.Size = new System.Drawing.Size(776, 258);
            this.GrdClientes.TabIndex = 8;
            this.GrdClientes.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GrdClientes_CellClick);
            // 
            // CliCodigo
            // 
            this.CliCodigo.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.CliCodigo.DataPropertyName = "CliCodigo";
            this.CliCodigo.HeaderText = "Código";
            this.CliCodigo.Name = "CliCodigo";
            this.CliCodigo.ReadOnly = true;
            // 
            // CliNome
            // 
            this.CliNome.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.CliNome.DataPropertyName = "CliNome";
            this.CliNome.HeaderText = "Nome";
            this.CliNome.Name = "CliNome";
            this.CliNome.ReadOnly = true;
            // 
            // CliCNPJ
            // 
            this.CliCNPJ.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.CliCNPJ.DataPropertyName = "CliCNPJ";
            dataGridViewCellStyle1.Format = "00.000.000-0";
            dataGridViewCellStyle1.NullValue = "-";
            this.CliCNPJ.DefaultCellStyle = dataGridViewCellStyle1;
            this.CliCNPJ.HeaderText = "CNPJ";
            this.CliCNPJ.Name = "CliCNPJ";
            this.CliCNPJ.ReadOnly = true;
            // 
            // CliCPF
            // 
            this.CliCPF.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.CliCPF.DataPropertyName = "CliCPF";
            dataGridViewCellStyle2.Format = "000.000.000-00";
            dataGridViewCellStyle2.NullValue = "-";
            this.CliCPF.DefaultCellStyle = dataGridViewCellStyle2;
            this.CliCPF.HeaderText = "CPF";
            this.CliCPF.Name = "CliCPF";
            this.CliCPF.ReadOnly = true;
            // 
            // CliNumero
            // 
            this.CliNumero.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.CliNumero.DataPropertyName = "CliNumero";
            this.CliNumero.HeaderText = "Número";
            this.CliNumero.Name = "CliNumero";
            this.CliNumero.ReadOnly = true;
            // 
            // CliRua
            // 
            this.CliRua.DataPropertyName = "CliRua";
            this.CliRua.HeaderText = "Rua";
            this.CliRua.Name = "CliRua";
            this.CliRua.ReadOnly = true;
            // 
            // CliBairro
            // 
            this.CliBairro.DataPropertyName = "CliBairro";
            this.CliBairro.HeaderText = "Bairro";
            this.CliBairro.Name = "CliBairro";
            this.CliBairro.ReadOnly = true;
            // 
            // CliCidade
            // 
            this.CliCidade.DataPropertyName = "CliCidade";
            this.CliCidade.HeaderText = "Cidade";
            this.CliCidade.Name = "CliCidade";
            this.CliCidade.ReadOnly = true;
            // 
            // BtnExcluir
            // 
            this.BtnExcluir.HeaderText = "Excluir";
            this.BtnExcluir.Name = "BtnExcluir";
            this.BtnExcluir.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.BtnExcluir.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // BtnAlterar
            // 
            this.BtnAlterar.HeaderText = "Alterar";
            this.BtnAlterar.Name = "BtnAlterar";
            // 
            // LblCliCNPJ
            // 
            this.LblCliCNPJ.AutoSize = true;
            this.LblCliCNPJ.Location = new System.Drawing.Point(320, 67);
            this.LblCliCNPJ.Name = "LblCliCNPJ";
            this.LblCliCNPJ.Size = new System.Drawing.Size(34, 13);
            this.LblCliCNPJ.TabIndex = 10;
            this.LblCliCNPJ.Text = "CNPJ";
            // 
            // TxtCliCNPJ
            // 
            this.TxtCliCNPJ.Location = new System.Drawing.Point(360, 64);
            this.TxtCliCNPJ.MaxLength = 9;
            this.TxtCliCNPJ.Name = "TxtCliCNPJ";
            this.TxtCliCNPJ.Size = new System.Drawing.Size(76, 20);
            this.TxtCliCNPJ.TabIndex = 20;
            // 
            // FrmCliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnCancelar);
            this.Controls.Add(this.BtnConfirmaAlteracao);
            this.Controls.Add(this.BtnFechar);
            this.Controls.Add(this.BtnIncluir);
            this.Controls.Add(this.LblCliCNPJ);
            this.Controls.Add(this.LblCPF);
            this.Controls.Add(this.LblFunNumero);
            this.Controls.Add(this.TxtCliCidade);
            this.Controls.Add(this.TxtCliBairro);
            this.Controls.Add(this.TxtCliRua);
            this.Controls.Add(this.TxtCliCNPJ);
            this.Controls.Add(this.TxtCliTel);
            this.Controls.Add(this.TxtCliCPF);
            this.Controls.Add(this.LblCidade);
            this.Controls.Add(this.LblBairro);
            this.Controls.Add(this.LblRua);
            this.Controls.Add(this.TxtCliCod);
            this.Controls.Add(this.TxtCliNome);
            this.Controls.Add(this.LblCodigo);
            this.Controls.Add(this.LblNome);
            this.Controls.Add(this.GrdClientes);
            this.Name = "FrmCliente";
            this.Text = "Cadastro de Clientes";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmCliente_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrmCliente_FormClosed);
            this.Load += new System.EventHandler(this.FrmCliente_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GrdClientes)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.Button BtnConfirmaAlteracao;
        private System.Windows.Forms.Button BtnFechar;
        private System.Windows.Forms.Button BtnIncluir;
        private System.Windows.Forms.Label LblCPF;
        private System.Windows.Forms.Label LblFunNumero;
        private System.Windows.Forms.TextBox TxtCliCidade;
        private System.Windows.Forms.TextBox TxtCliBairro;
        private System.Windows.Forms.TextBox TxtCliRua;
        private System.Windows.Forms.TextBox TxtCliTel;
        private System.Windows.Forms.TextBox TxtCliCPF;
        private System.Windows.Forms.Label LblCidade;
        private System.Windows.Forms.Label LblBairro;
        private System.Windows.Forms.Label LblRua;
        private System.Windows.Forms.TextBox TxtCliCod;
        private System.Windows.Forms.TextBox TxtCliNome;
        private System.Windows.Forms.Label LblCodigo;
        private System.Windows.Forms.Label LblNome;
        private System.Windows.Forms.DataGridView GrdClientes;
        private System.Windows.Forms.Label LblCliCNPJ;
        private System.Windows.Forms.TextBox TxtCliCNPJ;
        private System.Windows.Forms.DataGridViewTextBoxColumn CliCodigo;
        private System.Windows.Forms.DataGridViewTextBoxColumn CliNome;
        private System.Windows.Forms.DataGridViewTextBoxColumn CliCNPJ;
        private System.Windows.Forms.DataGridViewTextBoxColumn CliCPF;
        private System.Windows.Forms.DataGridViewTextBoxColumn CliNumero;
        private System.Windows.Forms.DataGridViewTextBoxColumn CliRua;
        private System.Windows.Forms.DataGridViewTextBoxColumn CliBairro;
        private System.Windows.Forms.DataGridViewTextBoxColumn CliCidade;
        private System.Windows.Forms.DataGridViewButtonColumn BtnExcluir;
        private System.Windows.Forms.DataGridViewButtonColumn BtnAlterar;
    }
}