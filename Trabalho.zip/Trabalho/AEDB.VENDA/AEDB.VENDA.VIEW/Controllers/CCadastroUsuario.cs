﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AEDB.VENDA.MODEL;
using AEDB.VENDA.MODEL.Repositories;

namespace AEDB.VENDA.VIEW.Controllers
{
    public class CCadastroUsuario:IDisposable
    {
        RepositoryUsuario _Repository;

        public CCadastroUsuario()
        {
            _Repository = new RepositoryUsuario();
        }

        public void Incluir(Usuario oUsu)
        {
            _Repository.Incluir(oUsu);
        }

        public void Alterar(Usuario oUsu)
        {
            _Repository.Alterar(oUsu);
        }

        public void Excluir(Usuario oUsu)
        {
            _Repository.Excluir(oUsu);
        }

        public Usuario Selecionar(string Codigo)
        {
            return _Repository.Selecionar(Codigo);
        }

        public List<Usuario> SelecionarTodos()
        {
            return _Repository.SelecionarTodos();
        }

        public void Dispose()
        {
            _Repository.Dispose();
        }
    }
}
