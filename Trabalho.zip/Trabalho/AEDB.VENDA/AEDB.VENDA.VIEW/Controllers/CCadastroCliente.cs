﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AEDB.VENDA.MODEL;
using AEDB.VENDA.MODEL.Repositories;

namespace AEDB.VENDA.VIEW.Controllers
{
    public class CCadastroCliente:IDisposable
    {
        RepositoryCliente _Repository;

        public CCadastroCliente()
        {
            _Repository = new RepositoryCliente();
        }

        public void Incluir(Cliente oCli)
        {
            _Repository.Incluir(oCli);
        }

        public void Alterar(Cliente oCli)
        {
            _Repository.Alterar(oCli);
        }

        public void Excluir(Cliente oCli)
        {
            _Repository.Excluir(oCli);
        }

        public Cliente Selecionar(string Codigo)
        {
            return _Repository.Selecionar(Codigo);
        }

        public List<Cliente> SelecionarTodos()
        {
            return _Repository.SelecionarTodos();
        }

        public void Dispose()
        {
            _Repository.Dispose();
        }
    }
}
