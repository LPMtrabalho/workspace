﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AEDB.VENDA.MODEL;
using AEDB.VENDA.MODEL.Repositories;

namespace AEDB.VENDA.VIEW.Controllers
{
    public class CCadastroFuncionario:IDisposable
    {
        RepositoryFuncionario _Repository;

        public CCadastroFuncionario()
        {
            _Repository = new RepositoryFuncionario();
        }

        public void Incluir(Funcionario oFunc)
        {
            _Repository.Incluir(oFunc);
        }

        public void Alterar(Funcionario oFunc)
        {
            _Repository.Alterar(oFunc);
        }

        public void Excluir(Funcionario oFunc)
        {
            _Repository.Excluir(oFunc);
        }

        public Funcionario Selecionar(string Codigo)
        {
            return _Repository.Selecionar(Codigo);
        }

        public List<Funcionario> SelecionarTodos()
        {
            return _Repository.SelecionarTodos();
        }

        public void Dispose()
        {
            _Repository.Dispose();
        }
    }
}
