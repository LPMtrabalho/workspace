﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AEDB.VENDA.MODEL;
using AEDB.VENDA.MODEL.Repositories;


namespace AEDB.VENDA.VIEW.Controllers
{
    public class CLogin : IDisposable
    {
        RepositoryUsuario _Repository = new RepositoryUsuario();

        public CLogin()
        {
        }

        public Usuario Autenticar(string Email, string Senha)
        {
            return _Repository.Selecionar(Email, Senha);
        }

        public void Dispose()
        {
            _Repository.Dispose();
        }
    }
}
