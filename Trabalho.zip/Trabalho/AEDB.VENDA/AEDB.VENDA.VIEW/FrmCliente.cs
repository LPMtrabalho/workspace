﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AEDB.VENDA.MODEL;
using AEDB.VENDA.VIEW.Controllers;
using AEDB.VENDA.MODEL.Helper;

namespace AEDB.VENDA.VIEW
{
    public partial class FrmCliente : Form
    {
        CCadastroCliente _Control;

        public FrmCliente()
        {
            InitializeComponent();
            _Control = new CCadastroCliente();
        }

        private void LimpaControles()
        {
            TxtCliCPF.Text = "";
            TxtCliNome.Text = "";
            TxtCliCNPJ.Text = "";
            TxtCliTel.Text = "";
            TxtCliRua.Text = "";
            TxtCliBairro.Text = "";
            TxtCliCidade.Text = "";
        }

        public void CarregaGrid()
        {
            GrdClientes.AutoGenerateColumns = false;
            GrdClientes.DataSource = _Control.SelecionarTodos();
        }

        private bool ValidaControles()
        {
            return true;
        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnConfirmaAlteracao_Click(object sender, EventArgs e)
        {
            try
            {
                //Cliente oClic = new Cliente();
                Cliente oClic = _Control.Selecionar(TxtCliCod.Text);
                if (oClic == null)
                {
                    MessageBox.Show("Não foi possível confirmar a alteração porque o sistema não enxontrou registros no Banco de Dados", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    oClic.CliNome = TxtCliNome.Text;
                    oClic.CliCNPJ = TxtCliCNPJ.Text;
                    oClic.CliCPF = TxtCliCPF.Text;
                    oClic.CliNumero = TxtCliTel.Text;
                    oClic.CliRua = TxtCliRua.Text;
                    oClic.CliBairro = TxtCliBairro.Text;
                    oClic.CliCidade = TxtCliCidade.Text;
                }
                BtnCancelar_Click(sender, e);
                CarregaGrid();
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException ex)
            {
                string erro = ex.Message;
                MessageBox.Show(MyGlobal.MsgErro(ex), ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(MyGlobal.MsgErro(ex), ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            TxtCliCod.Text = "";
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            LimpaControles();
            BtnConfirmaAlteracao.Enabled = false;
            BtnIncluir.Enabled = true;
            TxtCliNome.Focus();
            TxtCliCod.Text = "";
        }

        private void FrmCliente_Load(object sender, EventArgs e)
        {
            CarregaGrid();
            BtnConfirmaAlteracao.Enabled = false;
            TxtCliCod.Enabled = false;
        }

        private void BtnIncluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidaControles())
                {
                    Cliente oCliente = new Cliente();

                    oCliente.CliCPF = TxtCliCPF.Text;
                    oCliente.CliNome = TxtCliNome.Text;
                    oCliente.CliCNPJ = TxtCliCNPJ.Text;
                    oCliente.CliNumero = TxtCliTel.Text;
                    oCliente.CliRua = TxtCliRua.Text;
                    oCliente.CliBairro = TxtCliBairro.Text;
                    oCliente.CliCidade = TxtCliCidade.Text;
                    _Control.Incluir(oCliente);
                    CarregaGrid();
                    LimpaControles();
                }
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException ex)
            {
                string erro = ex.Message;
                MessageBox.Show(MyGlobal.MsgErro(ex), ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(MyGlobal.MsgErro(ex), ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FrmCliente_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (MessageBox.Show("Deseja fechar?", ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        private void GrdClientes_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex > -1)
                {
                    Cliente oCli = (Cliente)GrdClientes.Rows[e.RowIndex].DataBoundItem;
                    if (GrdClientes.Columns[e.ColumnIndex].Name == "BtnExcluir")
                    {
                        if (MessageBox.Show("Deseja realmente excluir?", ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            _Control.Excluir(oCli);
                            CarregaGrid();
                        }
                    }
                    else if (GrdClientes.Columns[e.ColumnIndex].Name == "BtnAlterar")
                    {
                        TxtCliCod.Text = oCli.CliCodigo.ToString();
                        TxtCliNome.Text = oCli.CliNome;
                        TxtCliCNPJ.Text = oCli.CliCNPJ;
                        TxtCliCPF.Text = oCli.CliCPF;
                        TxtCliTel.Text = oCli.CliNumero;
                        TxtCliRua.Text = oCli.CliRua;
                        TxtCliBairro.Text = oCli.CliBairro;
                        TxtCliCidade.Text = oCli.CliCidade;
                        TxtCliCod.Enabled = false;
                        BtnIncluir.Enabled = false;
                        BtnConfirmaAlteracao.Enabled = true;
                    }
                }
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException ex)
            {
                string erro = ex.Message;
                MessageBox.Show(MyGlobal.MsgErro(ex), ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(MyGlobal.MsgErro(ex), ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void FrmCliente_FormClosed(object sender, FormClosedEventArgs e)
        {
            ((FrmPrincipal)this.MdiParent).MnuCadCliente.Enabled = true;
        }
    }
}
