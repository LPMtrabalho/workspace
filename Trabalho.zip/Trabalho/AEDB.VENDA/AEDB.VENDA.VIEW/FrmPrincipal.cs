﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AEDB.VENDA.VIEW
{
    public partial class FrmPrincipal : Form
    {
        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void MnuCadFuncionario_Click(object sender, EventArgs e)
        {
            MnuCadFuncionario.Enabled = false;
            FrmFuncionarios oFun = new FrmFuncionarios();
            oFun.MdiParent = this;
            oFun.Show();
        }

        private void MnuCadCliente_Click(object sender, EventArgs e)
        {
            MnuCadCliente.Enabled = false;
            FrmCliente oCli = new FrmCliente();
            oCli.MdiParent = this;
            oCli.Show();
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            FrmLogin Frm = new FrmLogin();
            Frm.ShowDialog();
            if(Frm.Autenticado == false)
            {
                this.Close();
            }
        }

        private void sairToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
