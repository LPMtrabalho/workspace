﻿namespace AEDB.VENDA.VIEW
{
    partial class FrmLogin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TxtUsuEmail = new System.Windows.Forms.TextBox();
            this.TxtUsuSenha = new System.Windows.Forms.TextBox();
            this.LblUsuEmail = new System.Windows.Forms.Label();
            this.LblUsuSenha = new System.Windows.Forms.Label();
            this.BtnEntrar = new System.Windows.Forms.Button();
            this.BtnFechar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // TxtUsuEmail
            // 
            this.TxtUsuEmail.Location = new System.Drawing.Point(12, 40);
            this.TxtUsuEmail.MaxLength = 100;
            this.TxtUsuEmail.Name = "TxtUsuEmail";
            this.TxtUsuEmail.Size = new System.Drawing.Size(367, 20);
            this.TxtUsuEmail.TabIndex = 1;
            // 
            // TxtUsuSenha
            // 
            this.TxtUsuSenha.Location = new System.Drawing.Point(12, 88);
            this.TxtUsuSenha.MaxLength = 50;
            this.TxtUsuSenha.Name = "TxtUsuSenha";
            this.TxtUsuSenha.PasswordChar = '*';
            this.TxtUsuSenha.Size = new System.Drawing.Size(367, 20);
            this.TxtUsuSenha.TabIndex = 3;
            // 
            // LblUsuEmail
            // 
            this.LblUsuEmail.AutoSize = true;
            this.LblUsuEmail.Location = new System.Drawing.Point(9, 24);
            this.LblUsuEmail.Name = "LblUsuEmail";
            this.LblUsuEmail.Size = new System.Drawing.Size(35, 13);
            this.LblUsuEmail.TabIndex = 0;
            this.LblUsuEmail.Text = "E-mail";
            // 
            // LblUsuSenha
            // 
            this.LblUsuSenha.AutoSize = true;
            this.LblUsuSenha.Location = new System.Drawing.Point(9, 72);
            this.LblUsuSenha.Name = "LblUsuSenha";
            this.LblUsuSenha.Size = new System.Drawing.Size(38, 13);
            this.LblUsuSenha.TabIndex = 2;
            this.LblUsuSenha.Text = "Senha";
            // 
            // BtnEntrar
            // 
            this.BtnEntrar.Location = new System.Drawing.Point(12, 125);
            this.BtnEntrar.Name = "BtnEntrar";
            this.BtnEntrar.Size = new System.Drawing.Size(75, 23);
            this.BtnEntrar.TabIndex = 4;
            this.BtnEntrar.Text = "Entrar";
            this.BtnEntrar.UseVisualStyleBackColor = true;
            this.BtnEntrar.Click += new System.EventHandler(this.BtnEntrar_Click);
            // 
            // BtnFechar
            // 
            this.BtnFechar.Location = new System.Drawing.Point(93, 125);
            this.BtnFechar.Name = "BtnFechar";
            this.BtnFechar.Size = new System.Drawing.Size(75, 23);
            this.BtnFechar.TabIndex = 5;
            this.BtnFechar.Text = "Fechar";
            this.BtnFechar.UseVisualStyleBackColor = true;
            this.BtnFechar.Click += new System.EventHandler(this.BtnFechar_Click);
            // 
            // FrmLogin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(391, 179);
            this.ControlBox = false;
            this.Controls.Add(this.BtnFechar);
            this.Controls.Add(this.BtnEntrar);
            this.Controls.Add(this.LblUsuSenha);
            this.Controls.Add(this.LblUsuEmail);
            this.Controls.Add(this.TxtUsuSenha);
            this.Controls.Add(this.TxtUsuEmail);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "FrmLogin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Login";
            this.Load += new System.EventHandler(this.FrmLogin_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TxtUsuEmail;
        private System.Windows.Forms.TextBox TxtUsuSenha;
        private System.Windows.Forms.Label LblUsuEmail;
        private System.Windows.Forms.Label LblUsuSenha;
        private System.Windows.Forms.Button BtnEntrar;
        private System.Windows.Forms.Button BtnFechar;
    }
}