﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AEDB.VENDA.MODEL;
using AEDB.VENDA.VIEW.Controllers;
using AEDB.VENDA.MODEL.Helper;

namespace AEDB.VENDA.VIEW
{
    public partial class FrmFuncionarios : Form
    {
        CCadastroFuncionario _Control;

        public FrmFuncionarios()
        {
            InitializeComponent();
            _Control = new CCadastroFuncionario();
        }

        public void CarregaGrid()
        {
            GrdFuncionarios.AutoGenerateColumns = false;
            GrdFuncionarios.DataSource = _Control.SelecionarTodos();
        }

        private void FrmFuncionarios_Load(object sender, EventArgs e)
        {
            CarregaGrid();
            BtnConfirmaAlteracao.Enabled = false;
            TxtFunCod.Enabled = false;
        }

        private bool ValidaControles()
        {
            return true;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void MskFunRG_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        public void LimpaControles()
        {
            TxtFunCPF.Text = "";
            TxtFunNome.Text = "";
            TxtFunRG.Text = "";
            TxtFunTel.Text = "";
            TxtFunRua.Text = "";
            TxtFunBairro.Text = "";
            TxtFunCidade.Text = "";
        }

        private void BtnIncluir_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidaControles())
                {
                    Funcionario oFuncionario = new Funcionario();
                    
                    oFuncionario.FunCPF = TxtFunCPF.Text;
                    oFuncionario.FunNome = TxtFunNome.Text;
                    oFuncionario.FunRG = TxtFunRG.Text;
                    oFuncionario.FunNumero = TxtFunTel.Text;
                    oFuncionario.FunRua = TxtFunRua.Text;
                    oFuncionario.FunBairro = TxtFunBairro.Text;
                    oFuncionario.FunCidade = TxtFunCidade.Text;
                    _Control.Incluir(oFuncionario);
                    CarregaGrid();
                    LimpaControles();
                }
            }
            catch(System.Data.Entity.Validation.DbEntityValidationException ex)
            {
                string erro = ex.Message;
                MessageBox.Show(MyGlobal.MsgErro(ex), ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch(Exception ex)
            {
                MessageBox.Show(MyGlobal.MsgErro(ex), ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void LblCPF_Click(object sender, EventArgs e)
        {

        }

        private void BtnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void FrmFuncionarios_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(MessageBox.Show("Deseja fechar?", ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
                e.Cancel = true;
            }
        }

        private void GrdFuncionarios_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if(e.RowIndex > -1)
                {
                    Funcionario oFunc = (Funcionario)GrdFuncionarios.Rows[e.RowIndex].DataBoundItem;
                    if(GrdFuncionarios.Columns[e.ColumnIndex].Name == "BtnExcluir")
                    {
                        if(MessageBox.Show("Deseja realmente excluir?", ProductName, MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            _Control.Excluir(oFunc);
                            CarregaGrid();
                        }
                    }else if(GrdFuncionarios.Columns[e.ColumnIndex].Name == "BtnAlterar")
                    {
                        TxtFunCod.Text = oFunc.FunCod.ToString();
                        TxtFunNome.Text = oFunc.FunNome;
                        TxtFunRG.Text = oFunc.FunRG;
                        TxtFunCPF.Text = oFunc.FunCPF;
                        TxtFunTel.Text = oFunc.FunNumero;
                        TxtFunRua.Text = oFunc.FunRua;
                        TxtFunBairro.Text = oFunc.FunBairro;
                        TxtFunCidade.Text = oFunc.FunCidade;
                        TxtFunCod.Enabled = false;
                        BtnIncluir.Enabled = false;
                        BtnConfirmaAlteracao.Enabled = true;
                    }
                }
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException ex)
            {
                string erro = ex.Message;
                MessageBox.Show(MyGlobal.MsgErro(ex), ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(MyGlobal.MsgErro(ex), ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnCancelar_Click(object sender, EventArgs e)
        {
            LimpaControles();
            BtnConfirmaAlteracao.Enabled = false;
            BtnIncluir.Enabled = true;
            TxtFunNome.Focus();
            TxtFunCod.Text = "";
        }

        private void BtnConfirmaAlteracao_Click(object sender, EventArgs e)
        {
            try
            {
                //Funcionario oFunc = new Funcionario();
                Funcionario oFunc = _Control.Selecionar(TxtFunCod.Text);
                if(oFunc == null)
                {
                    MessageBox.Show("Não foi possível confirmar a alteração porque o sistema não enxontrou registros no Banco de Dados", ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    oFunc.FunNome = TxtFunNome.Text;
                    oFunc.FunRG = TxtFunRG.Text;
                    oFunc.FunCPF = TxtFunCPF.Text;
                    oFunc.FunNumero = TxtFunTel.Text;
                    oFunc.FunRua = TxtFunRua.Text;
                    oFunc.FunBairro = TxtFunBairro.Text;
                    oFunc.FunCidade = TxtFunCidade.Text;
                }
                BtnCancelar_Click(sender, e);
                CarregaGrid();
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException ex)
            {
                string erro = ex.Message;
                MessageBox.Show(MyGlobal.MsgErro(ex), ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(MyGlobal.MsgErro(ex), ProductName, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            TxtFunCod.Text = "";
        }

        private void FrmFuncionarios_FormClosed(object sender, FormClosedEventArgs e)
        {
            ((FrmPrincipal)this.MdiParent).MnuCadFuncionario.Enabled = true;
        }
    }
}
