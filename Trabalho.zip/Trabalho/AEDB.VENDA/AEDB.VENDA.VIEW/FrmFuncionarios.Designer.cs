﻿namespace AEDB.VENDA.VIEW
{
    partial class FrmFuncionarios
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.GrdFuncionarios = new System.Windows.Forms.DataGridView();
            this.LblNome = new System.Windows.Forms.Label();
            this.TxtFunNome = new System.Windows.Forms.TextBox();
            this.LblCPF = new System.Windows.Forms.Label();
            this.LblFunRG = new System.Windows.Forms.Label();
            this.LblFunNumero = new System.Windows.Forms.Label();
            this.BtnIncluir = new System.Windows.Forms.Button();
            this.LblRua = new System.Windows.Forms.Label();
            this.TxtFunRua = new System.Windows.Forms.TextBox();
            this.LblBairro = new System.Windows.Forms.Label();
            this.TxtFunBairro = new System.Windows.Forms.TextBox();
            this.LblCidade = new System.Windows.Forms.Label();
            this.TxtFunCidade = new System.Windows.Forms.TextBox();
            this.TxtFunRG = new System.Windows.Forms.TextBox();
            this.TxtFunCPF = new System.Windows.Forms.TextBox();
            this.TxtFunTel = new System.Windows.Forms.TextBox();
            this.BtnFechar = new System.Windows.Forms.Button();
            this.BtnConfirmaAlteracao = new System.Windows.Forms.Button();
            this.BtnCancelar = new System.Windows.Forms.Button();
            this.LblCodigo = new System.Windows.Forms.Label();
            this.TxtFunCod = new System.Windows.Forms.TextBox();
            this.FunCod = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FunNome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FunRG = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FunCPF = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FunNumero = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FunRua = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FunBairro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FunCidade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BtnExcluir = new System.Windows.Forms.DataGridViewButtonColumn();
            this.BtnAlterar = new System.Windows.Forms.DataGridViewButtonColumn();
            ((System.ComponentModel.ISupportInitialize)(this.GrdFuncionarios)).BeginInit();
            this.SuspendLayout();
            // 
            // GrdFuncionarios
            // 
            this.GrdFuncionarios.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrdFuncionarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GrdFuncionarios.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.FunCod,
            this.FunNome,
            this.FunRG,
            this.FunCPF,
            this.FunNumero,
            this.FunRua,
            this.FunBairro,
            this.FunCidade,
            this.BtnExcluir,
            this.BtnAlterar});
            this.GrdFuncionarios.Location = new System.Drawing.Point(12, 180);
            this.GrdFuncionarios.Name = "GrdFuncionarios";
            this.GrdFuncionarios.Size = new System.Drawing.Size(776, 258);
            this.GrdFuncionarios.TabIndex = 20;
            this.GrdFuncionarios.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.GrdFuncionarios_CellClick);
            this.GrdFuncionarios.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // LblNome
            // 
            this.LblNome.AutoSize = true;
            this.LblNome.Location = new System.Drawing.Point(12, 67);
            this.LblNome.Name = "LblNome";
            this.LblNome.Size = new System.Drawing.Size(35, 13);
            this.LblNome.TabIndex = 3;
            this.LblNome.Text = "Nome";
            // 
            // TxtFunNome
            // 
            this.TxtFunNome.Location = new System.Drawing.Point(50, 64);
            this.TxtFunNome.MaxLength = 50;
            this.TxtFunNome.Name = "TxtFunNome";
            this.TxtFunNome.Size = new System.Drawing.Size(264, 20);
            this.TxtFunNome.TabIndex = 4;
            // 
            // LblCPF
            // 
            this.LblCPF.AutoSize = true;
            this.LblCPF.Location = new System.Drawing.Point(431, 67);
            this.LblCPF.Name = "LblCPF";
            this.LblCPF.Size = new System.Drawing.Size(27, 13);
            this.LblCPF.TabIndex = 7;
            this.LblCPF.Text = "CPF";
            this.LblCPF.Click += new System.EventHandler(this.LblCPF_Click);
            // 
            // LblFunRG
            // 
            this.LblFunRG.AutoSize = true;
            this.LblFunRG.Location = new System.Drawing.Point(320, 67);
            this.LblFunRG.Name = "LblFunRG";
            this.LblFunRG.Size = new System.Drawing.Size(23, 13);
            this.LblFunRG.TabIndex = 5;
            this.LblFunRG.Text = "RG";
            // 
            // LblFunNumero
            // 
            this.LblFunNumero.AutoSize = true;
            this.LblFunNumero.Location = new System.Drawing.Point(546, 67);
            this.LblFunNumero.Name = "LblFunNumero";
            this.LblFunNumero.Size = new System.Drawing.Size(49, 13);
            this.LblFunNumero.TabIndex = 9;
            this.LblFunNumero.Text = "Telefone";
            // 
            // BtnIncluir
            // 
            this.BtnIncluir.Location = new System.Drawing.Point(395, 90);
            this.BtnIncluir.Name = "BtnIncluir";
            this.BtnIncluir.Size = new System.Drawing.Size(75, 21);
            this.BtnIncluir.TabIndex = 17;
            this.BtnIncluir.Text = "Incluir";
            this.BtnIncluir.UseVisualStyleBackColor = true;
            this.BtnIncluir.Click += new System.EventHandler(this.BtnIncluir_Click);
            // 
            // LblRua
            // 
            this.LblRua.AutoSize = true;
            this.LblRua.Location = new System.Drawing.Point(12, 93);
            this.LblRua.Name = "LblRua";
            this.LblRua.Size = new System.Drawing.Size(27, 13);
            this.LblRua.TabIndex = 11;
            this.LblRua.Text = "Rua";
            // 
            // TxtFunRua
            // 
            this.TxtFunRua.Location = new System.Drawing.Point(45, 90);
            this.TxtFunRua.MaxLength = 20;
            this.TxtFunRua.Name = "TxtFunRua";
            this.TxtFunRua.Size = new System.Drawing.Size(82, 20);
            this.TxtFunRua.TabIndex = 12;
            // 
            // LblBairro
            // 
            this.LblBairro.AutoSize = true;
            this.LblBairro.Location = new System.Drawing.Point(133, 93);
            this.LblBairro.Name = "LblBairro";
            this.LblBairro.Size = new System.Drawing.Size(34, 13);
            this.LblBairro.TabIndex = 13;
            this.LblBairro.Text = "Bairro";
            // 
            // TxtFunBairro
            // 
            this.TxtFunBairro.Location = new System.Drawing.Point(173, 90);
            this.TxtFunBairro.MaxLength = 20;
            this.TxtFunBairro.Name = "TxtFunBairro";
            this.TxtFunBairro.Size = new System.Drawing.Size(82, 20);
            this.TxtFunBairro.TabIndex = 14;
            // 
            // LblCidade
            // 
            this.LblCidade.AutoSize = true;
            this.LblCidade.Location = new System.Drawing.Point(261, 94);
            this.LblCidade.Name = "LblCidade";
            this.LblCidade.Size = new System.Drawing.Size(40, 13);
            this.LblCidade.TabIndex = 15;
            this.LblCidade.Text = "Cidade";
            // 
            // TxtFunCidade
            // 
            this.TxtFunCidade.Location = new System.Drawing.Point(307, 91);
            this.TxtFunCidade.MaxLength = 50;
            this.TxtFunCidade.Name = "TxtFunCidade";
            this.TxtFunCidade.Size = new System.Drawing.Size(82, 20);
            this.TxtFunCidade.TabIndex = 16;
            // 
            // TxtFunRG
            // 
            this.TxtFunRG.Location = new System.Drawing.Point(349, 64);
            this.TxtFunRG.MaxLength = 9;
            this.TxtFunRG.Name = "TxtFunRG";
            this.TxtFunRG.Size = new System.Drawing.Size(76, 20);
            this.TxtFunRG.TabIndex = 6;
            // 
            // TxtFunCPF
            // 
            this.TxtFunCPF.Location = new System.Drawing.Point(464, 64);
            this.TxtFunCPF.MaxLength = 11;
            this.TxtFunCPF.Name = "TxtFunCPF";
            this.TxtFunCPF.Size = new System.Drawing.Size(76, 20);
            this.TxtFunCPF.TabIndex = 8;
            // 
            // TxtFunTel
            // 
            this.TxtFunTel.Location = new System.Drawing.Point(601, 64);
            this.TxtFunTel.MaxLength = 20;
            this.TxtFunTel.Name = "TxtFunTel";
            this.TxtFunTel.Size = new System.Drawing.Size(76, 20);
            this.TxtFunTel.TabIndex = 10;
            // 
            // BtnFechar
            // 
            this.BtnFechar.Location = new System.Drawing.Point(12, 12);
            this.BtnFechar.Name = "BtnFechar";
            this.BtnFechar.Size = new System.Drawing.Size(75, 23);
            this.BtnFechar.TabIndex = 0;
            this.BtnFechar.Text = "Fechar";
            this.BtnFechar.UseVisualStyleBackColor = true;
            this.BtnFechar.Click += new System.EventHandler(this.BtnFechar_Click);
            // 
            // BtnConfirmaAlteracao
            // 
            this.BtnConfirmaAlteracao.Location = new System.Drawing.Point(12, 153);
            this.BtnConfirmaAlteracao.Name = "BtnConfirmaAlteracao";
            this.BtnConfirmaAlteracao.Size = new System.Drawing.Size(75, 21);
            this.BtnConfirmaAlteracao.TabIndex = 18;
            this.BtnConfirmaAlteracao.Text = "Alterar";
            this.BtnConfirmaAlteracao.UseVisualStyleBackColor = true;
            this.BtnConfirmaAlteracao.Click += new System.EventHandler(this.BtnConfirmaAlteracao_Click);
            // 
            // BtnCancelar
            // 
            this.BtnCancelar.Location = new System.Drawing.Point(93, 153);
            this.BtnCancelar.Name = "BtnCancelar";
            this.BtnCancelar.Size = new System.Drawing.Size(75, 21);
            this.BtnCancelar.TabIndex = 19;
            this.BtnCancelar.Text = "Cancelar";
            this.BtnCancelar.UseVisualStyleBackColor = true;
            this.BtnCancelar.Click += new System.EventHandler(this.BtnCancelar_Click);
            // 
            // LblCodigo
            // 
            this.LblCodigo.AutoSize = true;
            this.LblCodigo.Location = new System.Drawing.Point(12, 41);
            this.LblCodigo.Name = "LblCodigo";
            this.LblCodigo.Size = new System.Drawing.Size(40, 13);
            this.LblCodigo.TabIndex = 1;
            this.LblCodigo.Text = "Código";
            // 
            // TxtFunCod
            // 
            this.TxtFunCod.Location = new System.Drawing.Point(50, 38);
            this.TxtFunCod.MaxLength = 20;
            this.TxtFunCod.Name = "TxtFunCod";
            this.TxtFunCod.Size = new System.Drawing.Size(58, 20);
            this.TxtFunCod.TabIndex = 2;
            // 
            // FunCod
            // 
            this.FunCod.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.FunCod.DataPropertyName = "FunCod";
            this.FunCod.HeaderText = "Código";
            this.FunCod.Name = "FunCod";
            this.FunCod.ReadOnly = true;
            // 
            // FunNome
            // 
            this.FunNome.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.FunNome.DataPropertyName = "FunNome";
            this.FunNome.HeaderText = "Nome";
            this.FunNome.Name = "FunNome";
            this.FunNome.ReadOnly = true;
            // 
            // FunRG
            // 
            this.FunRG.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.FunRG.DataPropertyName = "FunRG";
            dataGridViewCellStyle1.Format = "00.000.000-0";
            dataGridViewCellStyle1.NullValue = "00.000.000-0";
            this.FunRG.DefaultCellStyle = dataGridViewCellStyle1;
            this.FunRG.HeaderText = "RG";
            this.FunRG.Name = "FunRG";
            this.FunRG.ReadOnly = true;
            // 
            // FunCPF
            // 
            this.FunCPF.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.FunCPF.DataPropertyName = "FunCPF";
            dataGridViewCellStyle2.Format = "000.000.000-00";
            dataGridViewCellStyle2.NullValue = "000.000.000-00";
            this.FunCPF.DefaultCellStyle = dataGridViewCellStyle2;
            this.FunCPF.HeaderText = "CPF";
            this.FunCPF.Name = "FunCPF";
            this.FunCPF.ReadOnly = true;
            // 
            // FunNumero
            // 
            this.FunNumero.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.FunNumero.DataPropertyName = "FunNumero";
            this.FunNumero.HeaderText = "Número";
            this.FunNumero.Name = "FunNumero";
            this.FunNumero.ReadOnly = true;
            // 
            // FunRua
            // 
            this.FunRua.DataPropertyName = "FunRua";
            this.FunRua.HeaderText = "Rua";
            this.FunRua.Name = "FunRua";
            this.FunRua.ReadOnly = true;
            // 
            // FunBairro
            // 
            this.FunBairro.DataPropertyName = "FunBairro";
            this.FunBairro.HeaderText = "Bairro";
            this.FunBairro.Name = "FunBairro";
            this.FunBairro.ReadOnly = true;
            // 
            // FunCidade
            // 
            this.FunCidade.DataPropertyName = "FunCidade";
            this.FunCidade.HeaderText = "Cidade";
            this.FunCidade.Name = "FunCidade";
            this.FunCidade.ReadOnly = true;
            // 
            // BtnExcluir
            // 
            this.BtnExcluir.HeaderText = "Excluir";
            this.BtnExcluir.Name = "BtnExcluir";
            this.BtnExcluir.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.BtnExcluir.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // BtnAlterar
            // 
            this.BtnAlterar.HeaderText = "Alterar";
            this.BtnAlterar.Name = "BtnAlterar";
            // 
            // FrmFuncionarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.BtnCancelar);
            this.Controls.Add(this.BtnConfirmaAlteracao);
            this.Controls.Add(this.BtnFechar);
            this.Controls.Add(this.BtnIncluir);
            this.Controls.Add(this.LblFunRG);
            this.Controls.Add(this.LblCPF);
            this.Controls.Add(this.LblFunNumero);
            this.Controls.Add(this.TxtFunCidade);
            this.Controls.Add(this.TxtFunBairro);
            this.Controls.Add(this.TxtFunRua);
            this.Controls.Add(this.TxtFunRG);
            this.Controls.Add(this.TxtFunTel);
            this.Controls.Add(this.TxtFunCPF);
            this.Controls.Add(this.LblCidade);
            this.Controls.Add(this.LblBairro);
            this.Controls.Add(this.LblRua);
            this.Controls.Add(this.TxtFunCod);
            this.Controls.Add(this.TxtFunNome);
            this.Controls.Add(this.LblCodigo);
            this.Controls.Add(this.LblNome);
            this.Controls.Add(this.GrdFuncionarios);
            this.Name = "FrmFuncionarios";
            this.Text = "Cadastro de Funcionários ";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmFuncionarios_FormClosing);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.FrmFuncionarios_FormClosed);
            this.Load += new System.EventHandler(this.FrmFuncionarios_Load);
            ((System.ComponentModel.ISupportInitialize)(this.GrdFuncionarios)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView GrdFuncionarios;
        private System.Windows.Forms.Label LblNome;
        private System.Windows.Forms.TextBox TxtFunNome;
        private System.Windows.Forms.Label LblCPF;
        private System.Windows.Forms.Label LblFunRG;
        private System.Windows.Forms.Label LblFunNumero;
        private System.Windows.Forms.Button BtnIncluir;
        private System.Windows.Forms.Label LblRua;
        private System.Windows.Forms.TextBox TxtFunRua;
        private System.Windows.Forms.Label LblBairro;
        private System.Windows.Forms.TextBox TxtFunBairro;
        private System.Windows.Forms.Label LblCidade;
        private System.Windows.Forms.TextBox TxtFunCidade;
        private System.Windows.Forms.TextBox TxtFunRG;
        private System.Windows.Forms.TextBox TxtFunCPF;
        private System.Windows.Forms.TextBox TxtFunTel;
        private System.Windows.Forms.Button BtnFechar;
        private System.Windows.Forms.Button BtnConfirmaAlteracao;
        private System.Windows.Forms.Button BtnCancelar;
        private System.Windows.Forms.Label LblCodigo;
        private System.Windows.Forms.TextBox TxtFunCod;
        private System.Windows.Forms.DataGridViewTextBoxColumn FunCod;
        private System.Windows.Forms.DataGridViewTextBoxColumn FunNome;
        private System.Windows.Forms.DataGridViewTextBoxColumn FunRG;
        private System.Windows.Forms.DataGridViewTextBoxColumn FunCPF;
        private System.Windows.Forms.DataGridViewTextBoxColumn FunNumero;
        private System.Windows.Forms.DataGridViewTextBoxColumn FunRua;
        private System.Windows.Forms.DataGridViewTextBoxColumn FunBairro;
        private System.Windows.Forms.DataGridViewTextBoxColumn FunCidade;
        private System.Windows.Forms.DataGridViewButtonColumn BtnExcluir;
        private System.Windows.Forms.DataGridViewButtonColumn BtnAlterar;
    }
}

