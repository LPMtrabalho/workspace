﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using AEDB.VENDA.MODEL.Helper;

namespace AEDB.VENDA.MODEL.Repositories
{
    public class RepositoryFuncionario:IDisposable
    {
        LojaDbEntities oDb;

        public RepositoryFuncionario()
        {
            oDb = MyGlobal.GetDataContext();
        }

        public void Incluir(Funcionario oFunc)
        { 
            oDb.Funcionario.Add(oFunc);
            try
            {
                oDb.SaveChanges();
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException dbEx)
            {
                Exception raise = dbEx;
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        string message = string.Format("{0}:{1}",
                            validationErrors.Entry.Entity.ToString(),
                            validationError.ErrorMessage);
                        // raise a new exception nesting
                        // the current instance as InnerException
                        raise = new InvalidOperationException(message, raise);
                    }
                }
                throw raise;
            }

        }

        public void Alterar(Funcionario oFunc)
        {
            oDb.Entry(oFunc).State = System.Data.Entity.EntityState.Modified;
            oDb.SaveChanges();
        }

        public void AlterarSemContexto(Funcionario oFunc)
        {
            oDb.Funcionario.Attach(oFunc);
            oDb.Entry(oFunc).State = System.Data.Entity.EntityState.Modified;
            oDb.SaveChanges();
        }

        public void Excluir(Funcionario oFunc, bool foraContexto = false)
        {
            if(foraContexto)
            {
                oDb.Funcionario.Attach(oFunc);
            }
            oDb.Funcionario.Remove(oFunc);
            oDb.SaveChanges();
        }

        public Funcionario Selecionar(string Codigo)
        {
            return (from p in oDb.Funcionario where p.FunCod.ToString() == Codigo select p).FirstOrDefault();
        }

        public List<Funcionario> SelecionarTodos()
        {
            return (from p in oDb.Funcionario orderby p.FunCod select p).ToList();
        }

        public void Dispose()
        {
            oDb.Dispose();
        }
    }
}
