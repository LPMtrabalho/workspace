﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AEDB.VENDA.MODEL.Helper;

namespace AEDB.VENDA.MODEL.Repositories
{
    public class RepositoryCliente:IDisposable
    {
        LojaDbEntities oDb;

        public RepositoryCliente()
        {
            oDb = MyGlobal.GetDataContext();
        }

        public void Incluir(Cliente oFunc)
        { 
            oDb.Cliente.Add(oFunc);
            try
            {
                oDb.SaveChanges();
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException dbEx)
            {
                Exception raise = dbEx;
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        string message = string.Format("{0}:{1}",
                            validationErrors.Entry.Entity.ToString(),
                            validationError.ErrorMessage);
                        // raise a new exception nesting
                        // the current instance as InnerException
                        raise = new InvalidOperationException(message, raise);
                    }
                }
                throw raise;
            }

        }

        public void Alterar(Cliente oFunc)
        {
            oDb.Entry(oFunc).State = System.Data.Entity.EntityState.Modified;
            oDb.SaveChanges();
        }

        public void AlterarSemContexto(Cliente oFunc)
        {
            oDb.Cliente.Attach(oFunc);
            oDb.Entry(oFunc).State = System.Data.Entity.EntityState.Modified;
            oDb.SaveChanges();
        }

        public void Excluir(Cliente oFunc, bool foraContexto = false)
        {
            if(foraContexto)
            {
                oDb.Cliente.Attach(oFunc);
            }
            oDb.Cliente.Remove(oFunc);
            oDb.SaveChanges();
        }

        public Cliente Selecionar(string Codigo)
        {
            return (from p in oDb.Cliente where p.CliCodigo.ToString() == Codigo select p).FirstOrDefault();
        }

        public List<Cliente> SelecionarTodos()
        {
            return (from p in oDb.Cliente orderby p.CliCodigo select p).ToList();
        }

        public void Dispose()
        {
            oDb.Dispose();
        }
    }
}
