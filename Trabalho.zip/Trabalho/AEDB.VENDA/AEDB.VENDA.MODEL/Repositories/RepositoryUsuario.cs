﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AEDB.VENDA.MODEL.Helper;

namespace AEDB.VENDA.MODEL.Repositories
{
    public class RepositoryUsuario:IDisposable
    {
        LojaDbEntities oDb;

        public RepositoryUsuario()
        {
            oDb = MyGlobal.GetDataContext();
        }

        public void Incluir(Usuario oUsu)
        { 
            oDb.Usuario.Add(oUsu);
            try
            {
                oDb.SaveChanges();
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException dbEx)
            {
                Exception raise = dbEx;
                foreach (var validationErrors in dbEx.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        string message = string.Format("{0}:{1}",
                            validationErrors.Entry.Entity.ToString(),
                            validationError.ErrorMessage);
                        // raise a new exception nesting
                        // the current instance as InnerException
                        raise = new InvalidOperationException(message, raise);
                    }
                }
                throw raise;
            }

        }

        public void Alterar(Usuario oUsu)
        {
            oDb.Entry(oUsu).State = System.Data.Entity.EntityState.Modified;
            oDb.SaveChanges();
        }

        public void AlterarSemContexto(Usuario oUsu)
        {
            oDb.Usuario.Attach(oUsu);
            oDb.Entry(oUsu).State = System.Data.Entity.EntityState.Modified;
            oDb.SaveChanges();
        }

        public void Excluir(Usuario oUsu, bool foraContexto = false)
        {
            if(foraContexto)
            {
                oDb.Usuario.Attach(oUsu);
            }
            oDb.Usuario.Remove(oUsu);
            oDb.SaveChanges();
        }

        public Usuario Selecionar(string email)
        {
            return (from p in oDb.Usuario where p.UsuEmail == email select p).FirstOrDefault();
        }

        public Usuario Selecionar(string email, string senha)
        {
            //senha = Helper.Criptografia.GerarHashMD5(senha);
            return (from p in oDb.Usuario where p.UsuEmail == email && p.UsuSenha==senha select p).FirstOrDefault();
        }

        public List<Usuario> SelecionarTodos()
        {
            return (from p in oDb.Usuario orderby p.UsuNome select p).ToList();
        }

        public void Dispose()
        {
            oDb.Dispose();
        }
    }
}
