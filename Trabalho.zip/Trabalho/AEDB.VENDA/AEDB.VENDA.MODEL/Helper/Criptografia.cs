﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;

namespace AEDB.VENDA.MODEL.Helper
{
    public class Criptografia
    {
       public static string GerarHashMD5(string input)
        {
            MD5 md5Hash = MD5.Create();

            //converter a string para array de bytes
            byte[] data = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(input));

            // Cria um string builder para compor a string 
            StringBuilder sBuilder = new StringBuilder();

            //loop para formatar cada byte como uma String em Hexadecimal 
            for (int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            return sBuilder.ToString();
        }
        
    }
}
