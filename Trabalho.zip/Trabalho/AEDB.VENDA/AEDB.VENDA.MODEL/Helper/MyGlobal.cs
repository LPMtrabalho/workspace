﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AEDB.VENDA.MODEL.Helper
{
    public class MyGlobal
    {
        public static LojaDbEntities GetDataContext()
        {
            LojaDbEntities oDb = new LojaDbEntities();

            oDb.Configuration.ProxyCreationEnabled = false;
            return oDb;
        }

        public static string MsgErro(Exception ex)
        {
            string erro = ex.Message;
            Exception ex1 = ex.InnerException;

            while (ex1 != null)
            {
                erro += " - " + ex1.Message;
                ex1 = ex1.InnerException;
            }

            return erro;
        }
    }
}
